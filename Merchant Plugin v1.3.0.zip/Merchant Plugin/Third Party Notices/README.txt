The receiver bundles CPython 3.12.14, SQLite, pyzmq 27.2.0 and its ZeroMQ libraries.
PyInstaller 6.22.2 builds the EXE and supplies its bootloader with a redistribution exception.
Third-party license texts are included here and in the bundled runtime.
EDMCModernOverlay is a separate dependency and is not bundled.
SQLite is in the public domain: https://sqlite.org/copyright.html
