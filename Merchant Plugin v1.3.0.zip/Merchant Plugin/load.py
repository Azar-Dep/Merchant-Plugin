"""EDMC entry point: a configurable, session-scoped Modern Overlay message."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import importlib
import json
import logging
import math
import os
from pathlib import Path
import re
import subprocess
import sqlite3
import threading
import time
import urllib.request

PLUGIN_NAME = "Merchant Plugin"
PLUGIN_VERSION = "1.3.0"
MESSAGE_ID = "elite-dangerous-merchant-message"
DEFAULTS = {"hotkey": "Ctrl+Alt+F3", "message": "Contacting Azar Dep...",
            "color": "#00ffff", "x": 40, "y": 100,
            "accepted_landing_pad_sizes": [],
            "only_orbiting_stations": True,
            "exclude_fleet_carriers": True,
            "max_trade_distance": "Any", "max_location_distance": "Any",
            "max_eddn_data_age": 6, "max_eddn_data_age_unit": "hours",
            "min_supply_at_buy_station": 1000}
LOG = logging.getLogger("EDMC.EliteDangerousMerchant")
_folder = Path(__file__).resolve().parent
_stop = threading.Event()
_thread = None
_collector = None
_overlay = None
_enabled = False
_location_lock = threading.Lock()
_location = {}
_location_dirty = False


def get_current_location():
    """The location supplied by this running copy of EDMC, never by EDDN."""
    with _location_lock:
        return dict(_location)


def _set_location(snapshot):
    global _location, _location_dirty
    with _location_lock:
        previous = {k: v for k, v in _location.items() if k not in {"updated_utc", "event"}}
        current = {k: v for k, v in snapshot.items() if k not in {"updated_utc", "event"}}
        if previous != current:
            snapshot["updated_utc"] = datetime.now(timezone.utc).isoformat()
            _location = snapshot
            _location_dirty = True


def _persist_location():
    global _location_dirty
    with _location_lock:
        if not _location_dirty:
            return
        snapshot = dict(_location)
        _location_dirty = False
    try:
        destination = _folder / "current-location.json"
        temporary = destination.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
        temporary.replace(destination)
    except OSError:
        with _location_lock:
            _location_dirty = True
        LOG.exception("Unable to save EDMC commander location")


def journal_entry(cmdr, is_beta, system, station, entry, state):
    """EDMC passes its own active commander and current location to this hook."""
    event = str(entry.get("event", ""))
    name = cmdr if isinstance(cmdr, str) and cmdr else None
    system_name = system if isinstance(system, str) and system else state.get("SystemName")
    if not isinstance(system_name, str) or not system_name:
        system_name = None
    docked = state.get("IsDocked") is True
    station_name = station if isinstance(station, str) and station else None
    if station_name is None and docked:
        station_name = state.get("StationName")
    if not isinstance(station_name, str) or not station_name:
        station_name = None
    if event in {"Undocked", "FSDJump", "SupercruiseEntry"}:
        station_name, docked = None, False
    if event in {"Fileheader", "Commander"}:
        # These precede the location snapshot for a newly selected commander.
        system_name, station_name, docked = None, None, False
    known = name is not None and system_name is not None
    active = known and event.casefold() != "shutdown"
    position = state.get("StarPos") or entry.get("StarPos")
    if (not isinstance(position, (list, tuple)) or len(position) != 3 or
            not all(type(v) in (int, float) and math.isfinite(v) for v in position) or not known):
        position = None
    else:
        position = list(position)
    _set_location({"source": "EDMC journal callback", "commander": name,
                   "system": system_name, "station": station_name,
                   "docked": docked, "is_beta": bool(is_beta),
                   "location_known": known, "game_session_active": active,
                   "edmc_running": True, "event": event, "star_pos": position})
    return None


def journal_entry_cqc(cmdr, is_beta, entry, state):
    """Arena does not have a normal galaxy location; do not retain one."""
    return journal_entry(cmdr, is_beta, None, None, entry, {})


def parse_hotkey(value):
    parts = [p.strip().lower() for p in value.split("+")]
    mods = {"ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10}
    keys, main = [], None
    for part in parts:
        if part in mods:
            if mods[part] in keys:
                raise ValueError("Duplicate hotkey modifier")
            keys.append(mods[part])
        elif main is not None:
            raise ValueError("Use one letter, number, or function key")
        elif re.fullmatch(r"[a-z0-9]", part):
            main = ord(part.upper())
        elif re.fullmatch(r"f([1-9]|1[0-9]|2[0-4])", part):
            main = 0x70 + int(part[1:]) - 1
        else:
            raise ValueError("Invalid hotkey")
    if not keys or main is None:
        raise ValueError("Use Ctrl, Alt, or Shift and one key")
    return tuple(keys), main


def read_settings(folder=None):
    result = dict(DEFAULTS)
    try:
        raw = json.loads(((folder or _folder) / "settings.json").read_text(encoding="utf-8-sig"))
        if not isinstance(raw, dict):
            raise ValueError("Settings must be an object")
        hotkey = raw.get("hotkey", result["hotkey"])
        parse_hotkey(hotkey)
        result["hotkey"] = hotkey
        color = raw.get("color", result["color"])
        if not isinstance(color, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            raise ValueError("Use a #RRGGBB color")
        result["color"] = color
        for key, maximum in (("x", 1279), ("y", 959)):
            number = raw.get(key, result[key])
            if type(number) is not int or not 0 <= number <= maximum:
                raise ValueError("Position must be inside the 1280 x 960 overlay canvas")
            result[key] = number
        pads = raw.get("accepted_landing_pad_sizes", result["accepted_landing_pad_sizes"])
        if (not isinstance(pads, list) or any(p not in {"Large", "Medium", "Small"} for p in pads)
                or len(set(pads)) != len(pads)):
            raise ValueError("Invalid landing pad sizes")
        result["accepted_landing_pad_sizes"] = pads
        orbiting = raw.get("only_orbiting_stations", True)
        if type(orbiting) is not bool:
            raise ValueError("Invalid orbiting station filter")
        result["only_orbiting_stations"] = orbiting
        exclude_carriers = raw.get("exclude_fleet_carriers", True)
        if type(exclude_carriers) is not bool:
            raise ValueError("Invalid fleet carrier filter")
        result["exclude_fleet_carriers"] = exclude_carriers
        for key in ("max_trade_distance", "max_location_distance"):
            value = raw.get(key, "Any")
            parsed = distance_limit(value)
            result[key] = "Any" if parsed is None else str(parsed)
        age = raw.get("max_eddn_data_age", result["max_eddn_data_age"])
        if type(age) is not int or age not in {2, 4, 6, 8, 10, 12}:
            raise ValueError("Select an EDDN data age from the dropdown")
        if raw.get("max_eddn_data_age_unit", "hours") != "hours":
            raise ValueError("EDDN data age uses hours")
        result["max_eddn_data_age"] = age
        supply = raw.get("min_supply_at_buy_station", result["min_supply_at_buy_station"])
        if type(supply) is not int or not 0 <= supply <= 2147483647:
            raise ValueError("Invalid minimum supply")
        result["min_supply_at_buy_station"] = supply
    except (OSError, ValueError, TypeError, AttributeError):
        return dict(DEFAULTS)
    return result


class WindowsInput:
    """Observe only the configured chord and Elite's foreground process."""
    def __init__(self):
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                           wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

    def game_focused(self):
        hwnd = self.user32.GetForegroundWindow()
        pid = wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        handle = self.kernel32.OpenProcess(0x1000, False, pid.value)
        if not handle:
            return False
        try:
            buffer = ctypes.create_unicode_buffer(32768)
            length = wintypes.DWORD(len(buffer))
            if not self.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
                return False
            return Path(buffer.value).name.casefold() in {"elitedangerous64.exe", "elitedangerous.exe"}
        finally:
            self.kernel32.CloseHandle(handle)

    def pressed(self, binding):
        modifiers, key = binding
        down = lambda vk: bool(self.user32.GetAsyncKeyState(vk) & 0x8000)
        return (down(key) and all(down(vk) == (vk in modifiers) for vk in (0x11, 0x12, 0x10))
                and not down(0x5B) and not down(0x5C))


class MessageState:
    """One toggle per key press; refresh a single expiring overlay item."""
    def __init__(self):
        self.enabled = False
        self.was_pressed = False
        self.sent = False
        self.next_send = 0
        self.binding = None
        self.on_toggle = None

    def step(self, focused, pressed, settings, now, send, clear):
        binding = parse_hotkey(settings["hotkey"])
        if binding != self.binding:
            self.binding = binding
            self.was_pressed = pressed
        elif focused and pressed and not self.was_pressed:
            self.enabled = not self.enabled
            self.next_send = 0
            if self.on_toggle:
                self.on_toggle(self.enabled, settings)
        self.was_pressed = pressed
        if self.enabled and focused:
            if now >= self.next_send:
                self.sent = send(settings)
                self.next_send = now + 1
        elif self.sent:
            clear()
            self.sent = False
            self.next_send = 0


def _connect_overlay():
    global _overlay
    if _overlay is None:
        module = importlib.import_module("EDMCOverlay.edmcoverlay")
        identity = getattr(module, "MODERN_OVERLAY_IDENTITY", {})
        if identity.get("plugin") != "EDMCModernOverlay":
            raise RuntimeError("EDMCModernOverlay is required")
        _overlay = module.send_overlay_message
    return _overlay


def _send(settings, text=None):
    try:
        return bool(_connect_overlay()({"event": "LegacyOverlay", "type": "message",
                    "plugin": PLUGIN_NAME, "id": MESSAGE_ID, "text": text if text is not None else settings["message"],
                    "color": settings["color"], "x": settings["x"], "y": settings["y"],
                    "ttl": 3, "size": "normal"}))
    except Exception:
        return False


def _clear():
    if _overlay is not None:
        try:
            _overlay({"event": "LegacyOverlay", "type": "legacy_clear",
                      "plugin": PLUGIN_NAME, "id": MESSAGE_ID, "ttl": 0})
        except Exception:
            LOG.debug("Overlay clearing failed", exc_info=True)


ORBITING_TYPES = {"coriolis", "orbis", "ocellus", "outpost", "asteroidbase", "megaship",
                  "fleetcarrier", "squadroncarrier"}


def display_name(value):
    return re.sub(r"\s+", " ", str(value or "")).strip().upper()


try:
    COMMODITY_NAMES = json.loads((_folder / "commodity_names.json").read_text(encoding="utf-8"))
except (OSError, ValueError):
    COMMODITY_NAMES = {"hydrogenfuel": "HYDROGEN FUEL"}


def commodity_display_name(value):
    key = str(value or "").strip().removeprefix("$").removesuffix(";")
    if key.casefold().endswith("_name"):
        key = key[:-5]
    if key.casefold() in COMMODITY_NAMES:
        return COMMODITY_NAMES[key.casefold()]
    key = re.sub(r"([a-z])([A-Z])", r"\1 \2", key).replace("_", " ")
    return display_name(key)


def distance_limit(value):
    if isinstance(value, str) and value.strip().casefold() == "any":
        return None
    if isinstance(value, bool):
        raise ValueError("Distance must be a nonnegative number or Any")
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise ValueError("Distance must be a nonnegative number or Any")
    return number


def system_distance(name_a, pos_a, name_b, pos_b):
    if name_a.casefold() == name_b.casefold():
        return 0.0
    if pos_a is None or pos_b is None:
        return None
    return math.sqrt(sum((b - a) ** 2 for a, b in zip(pos_a, pos_b)))


def find_best_trade(database, settings, location, now=None, cancelled=lambda: False):
    """Maximum profit per tonne, across all cached stations, without distance limits."""
    now = int(time.time()) if now is None else now
    if not location.get("location_known") or not location.get("game_session_active"):
        return {"message": "Waiting for current player location from EDMC."}
    if location.get("is_beta"):
        return {"message": "Trade search requires a live galaxy game session."}
    if not database.is_file():
        return {"message": "No EDDN data yet. Leave EDMC running to collect market reports."}
    route_limit = distance_limit(settings.get("max_trade_distance", "Any"))
    location_limit = distance_limit(settings.get("max_location_distance", "Any"))
    age_seconds = settings["max_eddn_data_age"] * 3600
    connection = sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True, timeout=2)
    connection.row_factory = sqlite3.Row
    connection.set_progress_handler(lambda: 1 if cancelled() else 0, 1000)
    try:
        # One SQLite snapshot keeps prices, metadata and coordinates consistent.
        connection.execute("BEGIN")
        tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"commodities", "markets", "station_metadata", "systems"} <= tables:
            return {"message": "Database update pending. Use the updated EDDN receiver and allow it to start."}
        rows = connection.execute("""SELECT c.*, m.system, m.station,
                   sm.station_type, sm.small_pads, sm.medium_pads, sm.large_pads, sm.arrival_ls,
                   sy.x, sy.y, sy.z
            FROM commodities c JOIN markets m ON m.market_id=c.market_id
            LEFT JOIN station_metadata sm ON sm.market_id=m.market_id
                AND sm.system=m.system COLLATE NOCASE AND sm.station=m.station COLLATE NOCASE
            LEFT JOIN systems sy ON sy.name=m.system COLLATE NOCASE
            WHERE c.reported_at>=? AND c.reported_at<=?
            ORDER BY c.name,c.sell_price DESC,c.market_id""", (now - age_seconds, now))
        groups = {}
        for row in rows:
            if cancelled():
                return None
            if settings["only_orbiting_stations"] and (row["station_type"] or "").casefold() not in ORBITING_TYPES:
                continue
            if settings.get("exclude_fleet_carriers", False):
                station_type = re.sub(r"[^a-z]", "", (row["station_type"] or "").casefold())
                carrier_tag = re.search(r"(?<![A-Z0-9])[A-Z0-9]{3}-[A-Z0-9]{3}(?![A-Z0-9])", (row["station"] or "").upper())
                if station_type in {"fleetcarrier", "squadroncarrier"} or carrier_tag:
                    continue
            pads = settings["accepted_landing_pad_sizes"]
            if pads and not any((row[size.lower() + "_pads"] or 0) > 0 for size in pads):
                continue
            group = groups.setdefault(row["name"], {"buys": [], "sells": []})
            if row["sell_price"] > 0 and row["demand"] > 0:
                group["sells"].append(dict(row))
            if row["buy_price"] > 0 and row["supply"] > 0 and row["supply"] >= settings["min_supply_at_buy_station"]:
                group["buys"].append(dict(row))

        origin = location.get("star_pos")
        if origin is None:
            origin_row = connection.execute("SELECT x,y,z FROM systems WHERE name=? COLLATE NOCASE", (location["system"],)).fetchone()
            if origin_row:
                origin = list(origin_row)
    finally:
        connection.close()
    def endpoint_position(row):
        if all(row[k] is not None for k in ("x", "y", "z")):
            return [row["x"], row["y"], row["z"]]
        return origin if row["system"].casefold() == location["system"].casefold() else None
    best = None
    missing_coordinates = False
    for commodity, group in groups.items():
        if cancelled():
            return None
        # Destinations are sorted by price; choose the first complete route within limits.
        group["buys"].sort(key=lambda r: (r["buy_price"], -r["reported_at"], r["market_id"]))
        destinations = group["sells"]
        for buy in group["buys"]:
            buy_position = endpoint_position(buy)
            current_distance = system_distance(location["system"], origin, buy["system"], buy_position)
            if current_distance is None:
                missing_coordinates = True
                continue
            if location_limit is not None and current_distance > location_limit:
                continue
            sell = None
            for candidate in destinations:
                if cancelled(): return None
                if candidate["market_id"] == buy["market_id"]: continue
                route_distance = system_distance(buy["system"], buy_position, candidate["system"], endpoint_position(candidate))
                if route_distance is None:
                    missing_coordinates = True
                    continue
                if route_limit is None or route_distance <= route_limit:
                    sell = candidate
                    break
            if sell is None:
                continue
            profit = sell["sell_price"] - buy["buy_price"]
            if profit <= 0:
                continue
            tie = (profit, min(buy["reported_at"], sell["reported_at"]), commodity, buy["market_id"], sell["market_id"])
            if best is None or tie > best[0]:
                best = tie, buy, sell
    if best is None and missing_coordinates:
        return {"message": "Contacting Azar Dep...", "waiting_for_coordinates": True}
    if best is None:
        return {"message": "No Trade Found\nNo profitable buy/sell pair in collected EDDN data meets your criteria."}
    _, buy, sell = best
    buy_pos, sell_pos = endpoint_position(buy), endpoint_position(sell)
    origin_distance = system_distance(location["system"], origin, buy["system"], buy_pos)
    route_distance = system_distance(buy["system"], buy_pos, sell["system"], sell_pos)
    result = {"buy": buy, "sell": sell, "profit_per_tonne": best[0][0],
              "origin_system": location["system"], "origin_station": location.get("station"),
              "to_buy_ly": origin_distance, "buy_to_sell_ly": route_distance,
              "expires_at": min(buy["reported_at"], sell["reported_at"]) + age_seconds}
    def ly(value):
        return "Unknown" if value is None else f"{value:,.2f}"
    commodity = commodity_display_name(buy["name"])
    buy_station, sell_station = display_name(buy["station"]), display_name(sell["station"])
    buy_system, sell_system = display_name(buy["system"]), display_name(sell["system"])
    deal = "a great deal" if result["profit_per_tonne"] > 10000 else "a deal"
    commander = location.get("commander") or "Unknown"
    result["message"] = (
        "AZAR DEP:\n\n"
        f"Hello there Commander {commander}. Thanks for contacting me.\n"
        f"I found {deal} for you {ly(origin_distance)}LY away from your location!\n\n"
        f"Buy {commodity} at {buy_station} in {buy_system} system. Buy Price: {buy['buy_price']:,} CR/Ton. "
        f"Available Supply: {buy['supply']:,}\n"
        f"Sell {commodity} at {sell_station} in {sell_system} system. Sell Price: {sell['sell_price']:,} CR/Ton.\n\n"
        f"Distance between {buy_system} and {sell_system} is: {ly(route_distance)}LY\n\n"
        f"Profit: {result['profit_per_tonne']:,} CR/Ton."
    )
    return result


def search_signature(settings, location):
    return (tuple(settings["accepted_landing_pad_sizes"]), settings["only_orbiting_stations"], settings.get("exclude_fleet_carriers", False), settings.get("max_trade_distance", "Any"), settings.get("max_location_distance", "Any"),
            settings["max_eddn_data_age"], settings["min_supply_at_buy_station"],
            location.get("commander"), location.get("system"), location.get("station"),
            tuple(location.get("star_pos") or ()), location.get("game_session_active"), location.get("is_beta"))


class TradeSearch:
    """One cancellable search worker; stale results cannot reappear after hiding."""
    def __init__(self, folder, locate=get_current_location, sender=_send, finder=find_best_trade, minimum_search_time=5.0):
        self.folder, self.locate, self.sender, self.finder = folder, locate, sender, finder
        self.minimum_search_time = minimum_search_time
        self.lock, self.wake, self.stop_event = threading.Lock(), threading.Event(), threading.Event()
        self.generation, self.enabled, self.job = 0, False, None
        self.text, self.signature, self.expires_at = "Contacting Azar Dep...", None, None
        self.coordinate_retry_at = None
        self.contact_started = time.monotonic()
        self.thread = threading.Thread(target=self._worker, name="MerchantSearch", daemon=True)
        self.thread.start()

    def start(self, settings):
        with self.lock:
            self.generation += 1
            self.enabled = True
            self.text = "Contacting Azar Dep..."
            self.signature = search_signature(settings, self.locate())
            self.expires_at = None
            self.coordinate_retry_at = None
            self.contact_started = time.monotonic()
            self.job = (self.generation, dict(settings), self.contact_started)
        self.sender(settings, "Contacting Azar Dep...")
        self.wake.set()

    def cancel(self):
        with self.lock:
            self.generation += 1
            self.enabled = False
            self.job = None

    def refresh_if_needed(self, settings):
        signature = search_signature(settings, self.locate())
        with self.lock:
            changed = self.enabled and (signature != self.signature or
                      (self.expires_at is not None and time.time() >= self.expires_at) or
                      (self.coordinate_retry_at is not None and time.time() >= self.coordinate_retry_at))
        if changed:
            self.start(settings)

    def render(self, settings):
        with self.lock:
            text = self.text
            elapsed = time.monotonic() - self.contact_started
        if text == "Contacting Azar Dep...":
            # Gentle four-second pulse, preserving the selected hue.
            strength = 0.85 + 0.15 * math.cos(elapsed * math.pi / 2)
            settings = dict(settings)
            color = settings["color"].lstrip("#")
            settings["color"] = "#" + "".join(f"{round(int(color[i:i+2], 16) * strength):02x}" for i in (0, 2, 4))
        return self.sender(settings, text)

    def _worker(self):
        while not self.stop_event.is_set():
            self.wake.wait(.25)
            self.wake.clear()
            with self.lock:
                job, self.job = self.job, None
            if job is None:
                continue
            generation, settings, started = job
            def cancelled():
                with self.lock:
                    return self.stop_event.is_set() or generation != self.generation or not self.enabled
            if cancelled():
                continue
            try:
                result = self.finder(self.folder / "eddn.sqlite3", settings, self.locate(), cancelled=cancelled)
            except sqlite3.OperationalError as error:
                if cancelled():
                    continue
                LOG.exception("Trade database search failed")
                result = {"message": "Trade database unavailable. Check the EDDN receiver log."}
            except Exception:
                LOG.exception("Trade search failed")
                result = {"message": "Trade search failed. See the EDMC log."}
            if result is None or cancelled():
                continue
            while not cancelled() and time.monotonic() < started + self.minimum_search_time:
                self.stop_event.wait(min(.1, max(0, started + self.minimum_search_time - time.monotonic())))
            if cancelled():
                continue
            with self.lock:
                if generation != self.generation or not self.enabled:
                    continue
                self.text = result["message"]
                self.expires_at = result.get("expires_at")
                self.coordinate_retry_at = (time.time() + 15 if result.get("waiting_for_coordinates") else None)
            try:
                destination = self.folder / "last-trade-search.json"
                temporary = destination.with_suffix(".json.tmp")
                temporary.write_text(json.dumps(result, indent=2), encoding="utf-8")
                temporary.replace(destination)
            except OSError:
                LOG.exception("Unable to write last trade search")

    def close(self):
        self.cancel()
        self.stop_event.set()
        self.wake.set()
        self.thread.join(timeout=3)


def _start_collector():
    global _collector
    executable = _folder / "Merchant EDDN Receiver.exe"
    if not executable.is_file():
        LOG.error("EDDN receiver missing: %s", executable)
        return
    try:
        _collector = subprocess.Popen([str(executable), "--database", str(_folder / "eddn.sqlite3"),
                                      "--status", str(_folder / "eddn-status.json"),
                                      "--log", str(_folder / "eddn-receiver.log"),
                                      "--settings", str(_folder / "settings.json"), "--watch-stdin"],
                                     stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, cwd=str(_folder),
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        LOG.exception("Unable to start the EDDN receiver")
        _collector = None


UPDATE_URL = "https://azars-den.azardep.chatgpt.site/merchant-version.json"
DOWNLOAD_URL = "https://azars-den.azardep.chatgpt.site/tools-of-the-arcane"
UPDATE_MESSAGE_ID = "merchant-plugin-update"


def json_plugin_version(content):
    data = json.loads(content)
    value = data.get("version") if isinstance(data, dict) else None
    if not isinstance(value, str):
        raise ValueError("Version JSON must contain a version string")
    match = re.fullmatch(r"v?(\d+)\.(\d+)\.(\d+)", value.strip(), re.I)
    if not match:
        raise ValueError("Version must have major.minor.patch format")
    return tuple(int(part) for part in match.groups())


def check_latest_version():
    request = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "MerchantPlugin/" + PLUGIN_VERSION, "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=10) as response:
        content = response.read(1024 * 1024 + 1)
        if len(content) > 1024 * 1024: raise ValueError("Version JSON too large")
        return json_plugin_version(content.decode("utf-8-sig"))


def send_update_notice(settings, text):
    try:
        return bool(_connect_overlay()({"event":"LegacyOverlay", "type":"message",
            "plugin":PLUGIN_NAME, "id":UPDATE_MESSAGE_ID, "text":text,
            "color":settings["color"], "x":settings["x"], "y":settings["y"], "ttl":10, "size":"normal"}))
    except Exception:
        return False


class UpdateNotice:
    def __init__(self, checker=check_latest_version, sender=send_update_notice):
        self.checker, self.sender = checker, sender
        self.started, self.latest, self.sent, self.ready_at = False, None, False, None
    def fetch(self):
        try: self.latest = self.checker()
        except Exception: LOG.warning("Unable to check Merchant Plugin updates", exc_info=True)
    def step(self, location, focused, settings, now):
        ready = focused and location.get("game_session_active") and location.get("location_known") and location.get("commander") and not location.get("is_beta")
        if not ready:
            self.ready_at = None
            return
        if self.ready_at is None: self.ready_at = now
        # Allow the game a few seconds to settle after EDMC supplies its location.
        if now - self.ready_at < 5: return
        if not self.started:
            self.started = True
            threading.Thread(target=self.fetch, name="MerchantUpdateCheck", daemon=True).start()
        installed = tuple(int(n) for n in PLUGIN_VERSION.split("."))
        if self.sent or self.latest is None or self.latest <= installed: return
        text = ("AZAR DEP:\n\n"
            f"Greetings Commander {location['commander']}. I've updated the Merchant Plugin.\n"
            f"Visit {DOWNLOAD_URL} to download it.")
        if self.sender(settings, text): self.sent = True


def _run():
    global _enabled
    search = None
    try:
        inputs = WindowsInput()
        state = MessageState()
        update_notice = UpdateNotice()
        search = TradeSearch(_folder)
        state.on_toggle = lambda enabled, options: search.start(options) if enabled else search.cancel()
        settings = read_settings()
        refresh_at, collector_check, next_warning = 0, 0, 0
        while not _stop.wait(0.03):
            now = time.monotonic()
            if now >= refresh_at:
                settings = read_settings()
                _persist_location()
                search.refresh_if_needed(settings)
                refresh_at = now + 1
            if now >= collector_check:
                if _collector is not None and _collector.poll() is not None:
                    if _collector.stdin:
                        _collector.stdin.close()
                    LOG.warning("EDDN receiver stopped; restarting")
                    _start_collector()
                collector_check = now + 15
            focused = inputs.game_focused()
            update_notice.step(get_current_location(), focused, settings, now)
            state.step(focused, inputs.pressed(parse_hotkey(settings["hotkey"])),
                       settings, now, search.render, _clear)
            _enabled = state.enabled
            if state.enabled and not state.sent and now >= next_warning:
                LOG.warning("Message enabled but not sent. Check that EDMCModernOverlay is installed and Elite has focus.")
                next_warning = now + 60
    except Exception:
        LOG.exception("Merchant hotkey worker stopped")
    finally:
        if search:
            search.close()
        _clear()


def plugin_start3(plugin_dir):
    global _folder, _thread, _enabled
    _folder = Path(plugin_dir).resolve()
    _enabled = False
    _stop.clear()
    _set_location({"source": "EDMC journal callback", "commander": None,
                   "system": None, "station": None, "docked": False,
                   "is_beta": False, "location_known": False,
                   "game_session_active": False, "edmc_running": True,
                   "event": "waiting for EDMC"})
    _start_collector()
    if os.name == "nt":
        _thread = threading.Thread(target=_run, name="MerchantOverlay", daemon=True)
        _thread.start()
    else:
        LOG.error("This package's hotkey and receiver require Windows")
    return PLUGIN_NAME


def plugin_stop():
    global _collector, _thread, _overlay
    _stop.set()
    if _thread:
        _thread.join(timeout=2)
        _thread = None
    _clear()
    _overlay = None
    snapshot = get_current_location()
    snapshot.update(edmc_running=False, game_session_active=False, event="EDMC stopped")
    _set_location(snapshot)
    _persist_location()
    process, _collector = _collector, None
    if process:
        try:
            if process.stdin:
                process.stdin.close()
            process.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
